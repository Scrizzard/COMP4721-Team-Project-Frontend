package com.example.singi_000.testmultiplescreens;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.widget.TextView;
import android.widget.TabHost;


public class MainActivity extends ActionBarActivity {

    public String inscriptionTitle = "Title of Inscription";
    public String inscriptionInfo = "This is the textual explanation of how to find the inscription. " +
            "We assume that this will be multi-lined and fairly lengthly in some cases, but smaller in others.";

    public void setTitle(){
        TextView title = (TextView) findViewById(R.id.titleView);
        title.setText(inscriptionTitle);
    }

    public void setInfo(){
        TextView info = (TextView) findViewById(R.id.infoView);
        info.setText(inscriptionInfo);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle();
        setInfo();

        TabHost tabhost = (TabHost) findViewById(R.id.tabHost);
        tabhost.setup();
        TabHost.TabSpec ts = tabhost.newTabSpec("tag1");
        ts.setContent(R.id.tab1);
        ts.setIndicator("First Tab");
        tabhost.addTab(ts);

        setTitle();
        setInfo();

        tabhost = (TabHost) findViewById(R.id.tabHost);
        tabhost.setup();
        ts = tabhost.newTabSpec("tag2");
        ts.setContent(R.id.tab1);
        ts.setIndicator("Second Tab");
        tabhost.addTab(ts);

        tabhost = (TabHost) findViewById(R.id.tabHost);
        tabhost.setup();
        ts= tabhost.newTabSpec("tag3");
        ts.setContent(R.id.tab1);
        ts.setIndicator("Third Tab");
        tabhost.addTab(ts);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
